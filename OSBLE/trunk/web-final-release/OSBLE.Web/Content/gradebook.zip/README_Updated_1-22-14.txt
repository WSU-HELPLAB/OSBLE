1/22/2014

This version is modified to check for a "#" in cell A1 of each worksheet before adding it to the list of worksheets to be uploaded.

If a "#" is not found in cell A1, that worksheet will not be uploaded.